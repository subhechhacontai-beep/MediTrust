# MediTrust ready-made website

## Run on Windows
1. Install Python 3.11.
2. Extract this ZIP and open the `MediTrust_Website` folder in VS Code.
3. Open Terminal > New Terminal and run:

```powershell
py -3.11 -m venv .venv
.venv\\Scripts\\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

If PowerShell blocks activation, run:
`Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`
Then activate again. Streamlit usually opens at http://localhost:8501.

## Publish online
Upload these files to a GitHub repository. Then sign in at https://share.streamlit.io/,
select the repository, branch `main`, and main file `app.py`, then deploy.
A live link requires your account authorization.

## Limitations
This is a retrieval prototype, not a fully generative medical AI. The similarity
indicator is not a validated hallucination detector. Bengali translation is not
implemented. Verify sample sources and expand the knowledge base before submission.
Never use it for diagnosis or treatment.
