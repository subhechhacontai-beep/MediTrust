from pathlib import Path
import re

def split_chunks(text, size=700, overlap=100):
    text = re.sub(r"\\s+", " ", text).strip()
    result, start = [], 0
    while start < len(text):
        end = min(start + size, len(text))
        result.append(text[start:end])
        if end == len(text):
            break
        start = end - overlap
    return result

def load_documents(folder):
    docs = []
    for path in Path(folder).glob("*.txt"):
        text = path.read_text(encoding="utf-8")
        for part in split_chunks(text):
            docs.append({"title": path.stem.replace("_", " ").title(),
                         "text": part, "url": "https://medlineplus.gov/"})
    if not docs:
        raise ValueError("No TXT files found in medical_documents.")
    return docs
