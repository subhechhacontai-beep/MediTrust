import streamlit as st
from pathlib import Path
from document_loader import load_documents
from retriever import Retriever
from database import save_question

st.set_page_config(page_title="MediTrust", page_icon="🩺", layout="wide")
st.title("🩺 MediTrust")
st.subheader("A Trustworthy AI-Based Medical Information Assistant")
st.warning("Educational information only. This prototype does not diagnose, prescribe, or replace a healthcare professional.")
with st.sidebar:
    st.header("MediTrust")
    language = st.selectbox("Language", ["English", "বাংলা (Bengali)"])
    st.caption("College-project demonstration")
    st.info("Bengali translation is not implemented in this starter version.")
@st.cache_resource
def load_search():
    docs = load_documents(Path(__file__).parent / "medical_documents")
    return Retriever(docs)
try:
    searcher = load_search()
    st.success(f"Knowledge base loaded: {len(searcher.docs)} passages")
except Exception as e:
    st.error(f"Could not load documents: {e}")
    st.stop()
question = st.text_area("Ask a general health question", placeholder="Example: What are common signs of dehydration?")
if st.button("Find information", type="primary", disabled=not question.strip()):
    results = searcher.search(question, 4)
    if not results or results[0]["score"] < 0.12:
        answer = "Insufficient evidence: the current knowledge base does not contain enough relevant information."
        st.warning(answer)
    else:
        answer = "Relevant passages retrieved from the supplied educational documents:"
        st.markdown("### Retrieved information")
        st.write(answer)
        for i, item in enumerate(results, 1):
            with st.expander(f"{i}. {item['title']} (similarity {item['score']:.2f})"):
                st.write(item["text"])
                st.markdown(f"[Check suggested source]({item['url']})")
        st.info("Similarity helps find related text; it does not prove medical correctness.")
    save_question(question, answer, language)
st.divider()
st.caption("For worrying symptoms, contact a qualified healthcare professional. Do not use this academic prototype for medical decisions.")
