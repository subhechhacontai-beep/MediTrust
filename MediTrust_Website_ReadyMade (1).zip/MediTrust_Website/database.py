import sqlite3
from pathlib import Path
DB = Path(__file__).parent / "meditrust.sqlite3"

def save_question(question, answer, language):
    with sqlite3.connect(DB) as con:
        con.execute("""CREATE TABLE IF NOT EXISTS history(
            id INTEGER PRIMARY KEY, question TEXT, answer TEXT, language TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
        con.execute("INSERT INTO history(question,answer,language) VALUES(?,?,?)",
                    (question, answer, language))
