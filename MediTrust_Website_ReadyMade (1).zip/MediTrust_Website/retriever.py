import numpy as np

class Retriever:
    def __init__(self, docs):
        self.docs = docs
        self.model = None
        try:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
            self.vectors = self.model.encode([d["text"] for d in docs],
                normalize_embeddings=True, convert_to_numpy=True).astype("float32")
            try:
                import faiss
                self.index = faiss.IndexFlatIP(self.vectors.shape[1])
                self.index.add(self.vectors)
            except Exception:
                self.index = None
        except Exception:
            from sklearn.feature_extraction.text import TfidfVectorizer
            self.vectorizer = TfidfVectorizer(stop_words="english")
            self.matrix = self.vectorizer.fit_transform([d["text"] for d in docs])

    def search(self, question, k=4):
        if self.model is not None:
            q = self.model.encode([question], normalize_embeddings=True, convert_to_numpy=True).astype("float32")
            if self.index is not None:
                scores, ids = self.index.search(q, min(k, len(self.docs)))
                pairs = [(int(i), float(s)) for i, s in zip(ids[0], scores[0]) if i >= 0]
            else:
                scores = self.vectors @ q[0]
                pairs = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)[:k]
        else:
            q = self.vectorizer.transform([question])
            scores = (self.matrix @ q.T).toarray().ravel()
            pairs = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)[:k]
        return [{**self.docs[i], "score": score} for i, score in pairs]
